<?php
$id = $_GET['id'];
$query = mysqli_query($connection, "DELETE FROM kategoribuku WHERE kategoriID=$id");
?>
<script>
    alert('Hapus Data Berhasil');
    location.href = "index.php?page=kategori";
</script>
