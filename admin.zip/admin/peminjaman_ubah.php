<div class="card border-left-dark">
    <div class="card-body">
        <div class="row">
            <div class="col-md-9">
                <form method="post">
                <?php 
                    $id = $_GET['id'];
                        if(isset($_POST['submit']))
                        {
                            $id_buku = $_POST['id_buku'];
                            $id_user = $_SESSION['user']['userID'];
                            $tanggal_peminjaman = $_POST['tanggal_peminjaman'];
                            $tanggal_pengembalian = $_POST['tanggal_pengembalian'];
                            $status_peminjaman = $_POST['status_peminjaman'];
                            $query = mysqli_query($connection, "UPDATE peminjaman set bukuID='$id_buku', tanggal_peminjaman='$tanggal_peminjaman',tanggal_pengembalian='$tanggal_pengembalian',status_peminjaman='$status_peminjaman' WHERE peminjamanID=$id");

                            if($query)
                            {
                                echo    '<script>alert("Ubah Data Berhasil");</script>';
                            }
                            else 
                            {
                                echo    '<script>alert("Ubah Data Gagal");</script>';
                            }
                        }
                        $query = mysqli_query($connection, "SELECT*FROM peminjaman WHERE peminjamanID=$id");
                        $data = mysqli_fetch_array($query);
                        ?>
                    <div class="row mb-3">
                        <div class="col-md-4">Buku</div>
                        <div class="col-md-8">
                            <select name="id_buku" class="form-control">
                                <?php
                                $buk = mysqli_query($connection, "SELECT*FROM buku");
                                while($buku = mysqli_fetch_array($buk))
                                {
                                    ?>
                                    <option value="<?php echo $buku['bukuID']; ?>"><?php echo $buku['judul'];?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">Tanggal Peminjaman</div>
                        <div class="col-md-8"><input type="date" class="form-control" name="tanggal_peminjaman"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">Tanggal Pengembalian</div>
                        <div class="col-md-8"><input type="date" class="form-control" name="tanggal_pengembalian"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">Status Peminjaman</div>
                        <div class="col-md-8">
                            <select name="status_peminjaman" class="form-control">
                                <option value="dipinjam">Dipinjam</option>
                                <option value="dikembalikan">Dikembalikan</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-success" name="submit" value="submit">Simpan</button>
                            <button type="reset" class="btn btn-danger">Reset</button>
                            <a href="?page-peminjaman" class="btn btn-secondary">Kembali</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
