<h1 class="mt-4 error" data-text="Error">Error</h1>
<p class="lead text-gray-800 mb-5">Halaman tidak ditemukan</p>